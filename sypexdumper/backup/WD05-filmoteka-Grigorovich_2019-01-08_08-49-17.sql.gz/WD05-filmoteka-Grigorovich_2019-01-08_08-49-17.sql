#SXD20|20011|50719|70107|2019.01.08 08:49:17|WD05-filmoteka-Grigorovich|utf8|1|10|
#TA films`10`16384
#EOH

#	TC`films`utf8_general_ci	;
CREATE TABLE `films` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` tinytext NOT NULL,
  `genre` tinytext NOT NULL,
  `year` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8	;
#	TD`films`utf8_general_ci	;
INSERT INTO `films` VALUES 
(1,'Такси 2','комедия',2000),
(2,'Облачный атлас','драма',2012),
(3,'Нирвана','Драма/Кинофантастика',1997),
(5,'Ровер','Драма/Криминальный фильм',2014),
(7,'Здравствуй, папа, Новый год!','Комедия/Семейный',2015),
(8,'Первому игроку приготовиться','Триллер/Кинофантастика',2018),
(9,'Апгрейд','Триллер/Фэнтези',2018),
(10,'Гоголь. Вий','Драма/Фэнтези',2018),
(11,'Непрощённый','Драма',2018),
(12,'Хан Соло: Звёздные Войны. Истории','Фэнтези/Кинофантастика',2018)	;
