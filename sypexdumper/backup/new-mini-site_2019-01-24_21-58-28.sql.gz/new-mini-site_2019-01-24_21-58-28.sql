#SXD20|20011|80012|70210|2019.01.24 21:58:28|new-mini-site|0|1|13|
#TA users`13`16384
#EOH

#	TC`users`utf8_general_ci	;
CREATE TABLE `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` text NOT NULL,
  `email` text NOT NULL,
  `password` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8	;
#	TD`users`utf8_general_ci	;
INSERT INTO `users` VALUES 
(1,'Batman','batman@gmail.com','111555'),
(2,'Batman','batman@gmail.com','111555'),
(3,'Superman','superman@gmail.com','XXX'),
(4,'Joker','joker@hotmail.com','555'),
(5,'Brayan O\'Konor','brayan@hotmail.com','111'),
(6,'Richard O\'Neil','richard@tut.by','7829'),
(7,'Elizabeth Mc\'Neal','elizabet@uac.com','lizz'),
(8,'Андрей Арловский','arlovski@yahoo.com','Pitbull'),
(9,'Svonn','svonn@uac.com','892='),
(10,'Serious Sam','sam@earth.org','SeriousPassword'),
(11,'Tony Stark','ironman@gmail.com','ironfirst'),
(12,'Frank Delgardo','delgardo@squad.org','FireWalkWithMe'),
(13,'New Flash','flash@gmail.com','777')	;
