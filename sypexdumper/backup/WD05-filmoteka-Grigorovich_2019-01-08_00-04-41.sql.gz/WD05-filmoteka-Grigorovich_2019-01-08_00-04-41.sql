#SXD20|20011|50720|70200|2019.01.08 00:04:41|WD05-filmoteka-Grigorovich|utf8|1|5|
#TA films`5`16384
#EOH

#	TC`films`utf8_general_ci	;
CREATE TABLE `films` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` tinytext NOT NULL,
  `genre` tinytext NOT NULL,
  `year` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8	;
#	TD`films`utf8_general_ci	;
INSERT INTO `films` VALUES 
(1,'Такси 2','комедия',2000),
(2,'Облачный атлас','драма',2012),
(3,'Нирвана','Драма/Кинофантастика',1997),
(5,'Ровер','Драма/Криминальный фильм',2014),
(7,'Здравствуй, папа, Новый год!','Комедия/Семейный',2015)	;
